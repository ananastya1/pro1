# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'project.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Patients(object):
    def setupUi(self, Patients):
        Patients.setObjectName("Patients")
        Patients.resize(1255, 728)
        self.pushButton = QtWidgets.QPushButton(Patients)
        self.pushButton.setGeometry(QtCore.QRect(20, 670, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Patients)
        self.pushButton_2.setGeometry(QtCore.QRect(250, 670, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(Patients)
        self.pushButton_3.setGeometry(QtCore.QRect(480, 670, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        self.tableWidget = QtWidgets.QTableWidget(Patients)
        self.tableWidget.setGeometry(QtCore.QRect(20, 30, 1221, 621))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)
        self.pushButton_4 = QtWidgets.QPushButton(Patients)
        self.pushButton_4.setGeometry(QtCore.QRect(690, 670, 171, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_5 = QtWidgets.QPushButton(Patients)
        self.pushButton_5.setGeometry(QtCore.QRect(880, 670, 171, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_5.setFont(font)
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_6 = QtWidgets.QPushButton(Patients)
        self.pushButton_6.setGeometry(QtCore.QRect(1080, 670, 171, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_6.setFont(font)
        self.pushButton_6.setObjectName("pushButton_6")

        self.retranslateUi(Patients)
        QtCore.QMetaObject.connectSlotsByName(Patients)

    def retranslateUi(self, Patients):
        _translate = QtCore.QCoreApplication.translate
        Patients.setWindowTitle(_translate("Patients", "Patients"))
        self.pushButton.setText(_translate("Patients", "Добавить"))
        self.pushButton_2.setText(_translate("Patients", "Изменить"))
        self.pushButton_3.setText(_translate("Patients", "Удалить"))
        self.pushButton_4.setText(_translate("Patients", "Выбрать"))
        self.pushButton_5.setText(_translate("Patients", "Отсортировать"))
        self.pushButton_6.setText(_translate("Patients", "О программе"))
