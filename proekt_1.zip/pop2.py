import sys
import sqlite3
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5.QtWidgets import QMainWindow, QMessageBox
from PyQt5.QtWidgets import QTableWidgetItem, QPushButton
from PyQt5.QtWidgets import QLabel, QTextBrowser
from PyQt5.QtWidgets import QInputDialog
from project1 import Ui_Patients
from project2 import Ui_Form2
from project3 import Ui_Form


class MyWidget(QMainWindow, Ui_Patients):
    def __init__(self):
        global rows, num_rows, text, note
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.con = sqlite3.connect('pro_bd.db')
        cur = self.con.cursor()
        self.result = cur.execute('SELECT * FROM patients').fetchall()
        self.showing(self.result)
        self.pushButton.clicked.connect(self.adding)
        self.pushButton_2.clicked.connect(self.editing)
        self.pushButton_3.clicked.connect(self.delete)
        self.pushButton_4.clicked.connect(self.filter)
        self.pushButton_5.clicked.connect(self.sorting)
        self.pushButton_6.clicked.connect(self.description)

    def showing(self, result):
        self.result = result
        if self.result:
            self.tableWidget.setRowCount(len(self.result))
            self.tableWidget.setColumnCount(len(self.result[0]))
            self.tableWidget.setHorizontalHeaderLabels(['id', 'фамилия', 'имя', 'отчество',
                                                        'возраст', 'пол', 'необходимо',
                                                        'осталось', 'телефон', 'заболевание'])
            for i, row in enumerate(self.result):
                for j, col in enumerate(row):
                    self.tableWidget.setItem(i, j, QTableWidgetItem(str(col)))
            self.tableWidget.resizeColumnsToContents()

    def adding(self):
        self.otherwindow = Addition()
        self.otherwindow.show()
        self.con = sqlite3.connect('pro_bd.db')
        cur = self.con.cursor()
        self.result = cur.execute('SELECT * FROM patients').fetchall()
        self.showing(self.result)

    def editing(self):
        note = []
        res = self.tableWidget.selectedItems()
        if len(res) == 0:
            QMessageBox.question(self, 'Сообщение', 'Запись не выбрана',
                                 QMessageBox.Ok)
        else:
            for i in res:
                note.append(self.result[i.row()])
            self.otherwindow = Redaction(note)
            self.otherwindow.show()
            self.con = sqlite3.connect('pro_bd.db')
            cur = self.con.cursor()
            self.result = cur.execute('SELECT * FROM patients').fetchall()
            self.showing(self.result)

    def delete(self):
        res = self.tableWidget.selectedItems()
        if len(res) == 0:
            QMessageBox.question(self, 'Сообщение', 'Запись не выбрана',
                                 QMessageBox.Ok)
        else:
            rows = set()
            num_rows = set()
            for i in res:
                rows.add(self.result[i.row()])
                num_rows.add(i.row())
            self.otherwindow = Deletion(rows, num_rows)
            self.otherwindow.show()
            self.con = sqlite3.connect('pro_bd.db')
            cur = self.con.cursor()
            self.result = cur.execute('SELECT * FROM patients').fetchall()
            self.showing(self.result)

    def filter(self):
        i, okBtnPressed = QInputDialog.getItem(self, "Выбор",
                                               "Выберите параметр для выбора",
                                               ("мужчины", "женщины", "младше 18 лет",
                                                "старше 18 лет", "нуждается в сборе средств",
                                                "средства собраны", "все"),
                                               0, True)
        if okBtnPressed:
            self.con = sqlite3.connect('pro_bd.db')
            cur = self.con.cursor()
            if i == 'мужчины':
                self.result = cur.execute('SELECT * FROM patients WHERE пол = "м"').fetchall()
            elif i == 'женщины':
                self.result = cur.execute('SELECT * FROM patients WHERE пол = "ж"').fetchall()
            elif i == 'младше 18 лет':
                self.result = cur.execute('SELECT * FROM patients WHERE возраст < 18').fetchall()
            elif i == 'старше 18 лет':
                self.result = cur.execute('SELECT * FROM patients WHERE возраст >= 18').fetchall()
            elif i == 'нуждается в сборе средств':
                self.result = cur.execute('SELECT * FROM patients WHERE осталось > 0').fetchall()
            elif i == 'средства собраны':
                self.result = cur.execute('SELECT * FROM patients WHERE осталось <= 0').fetchall()
            elif i == 'все':
                self.result = cur.execute('SELECT * FROM patients').fetchall()
        self.showing(self.result)

    def sorting(self):
        self.con = sqlite3.connect('pro_bd.db')
        cur = self.con.cursor()
        i, okBtnPressed = QInputDialog.getItem(self, "Сортировка",
                                               "Выберите параметр для сортировки",
                                               ("фамилия", "id", "возраст"),
                                               1, True)
        if okBtnPressed:
            if i == 'фамилия':
                self.result = cur.execute('''SELECT * FROM patients
                                             ORDER BY фамилия''').fetchall()
            elif i == 'id':
                self.result = cur.execute('''SELECT * FROM patients
                                             ORDER BY id''').fetchall()
            elif i == 'возраст':
                self.result = cur.execute('''SELECT * FROM patients
                                             ORDER BY возраст''').fetchall()
        self.showing(self.result)

    def description(self):
        with open('description.txt', 'r') as f:
            self.text = f.read()
        f.close()
        self.otherwindow = Desc(self.text)
        self.otherwindow.show()


class Deletion(QWidget):
    def __init__(self, rows, num_rows):
        super().__init__()
        self.initUI()
        self.rows = rows
        self.num_rows = num_rows

    def initUI(self):
        self.setGeometry(600, 400, 250, 110)
        self.setWindowTitle('Удаление')

        self.button_1 = QPushButton(self)
        self.button_1.move(20, 70)
        self.button_1.setText("Да")
        self.button_1.clicked.connect(self.run)

        self.button_2 = QPushButton(self)
        self.button_2.move(150, 70)
        self.button_2.setText("Нет")
        self.button_2.clicked.connect(self.close)

        self.quest = QLabel(self)
        self.quest.move(20, 30)
        self.quest.setText('Удалить выбранную запись?')

        self.show()

    def run(self):
        self.con = sqlite3.connect('pro_bd.db')
        cur = self.con.cursor()
        for i in self.rows:
            cur.execute('DELETE FROM patients WHERE id = ?', (str(i[0]),))
        for i in self.num_rows:
            ex.tableWidget.removeRow(i)
        self.con.commit()
        result = cur.execute('SELECT * FROM patients').fetchall()
        ex.showing(result)
        self.close()


class Redaction(QWidget, Ui_Form):
    def __init__(self, note):
        super().__init__()
        self.setupUi(self)
        self.note = note
        self.initUI()

    def initUI(self):
        self.id = self.lineEdit.setText(str(self.note[0][0]))
        self.surname = self.lineEdit_3.setText(self.note[0][1])
        self.name = self.lineEdit_4.setText(self.note[0][2])
        self.pat = self.lineEdit_5.setText(self.note[0][3])
        self.age = self.lineEdit_6.setText(str(self.note[0][4]))
        self.gender = self.lineEdit_7.setText(str(self.note[0][5]))
        self.summa = self.lineEdit_8.setText(str(self.note[0][6]))
        self.ost = self.lineEdit_9.setText(str(self.note[0][7]))
        self.num = self.lineEdit_10.setText(str(self.note[0][8]))
        self.disease = self.lineEdit_11.setText(self.note[0][9])

        self.show()
        self.pushButton.clicked.connect(self.run)
        self.pushButton_2.clicked.connect(self.closing)

    def run(self):
        self.id = self.lineEdit.text()
        self.surname = self.lineEdit_3.text()
        self.name = self.lineEdit_4.text()
        self.pat = self.lineEdit_5.text()
        self.age = self.lineEdit_6.text()
        self.gender = self.lineEdit_7.text()
        self.summa = self.lineEdit_8.text()
        self.ost = self.lineEdit_9.text()
        self.num = self.lineEdit_10.text()
        self.disease = self.lineEdit_11.text()
        self.con = sqlite3.connect('pro_bd.db')
        cur = self.con.cursor()
        cur.execute('''UPDATE patients
                       SET фамилия = ?,
                       имя = ?, отчество = ?,
                       возраст = ?, пол = ?,
                       необходимо = ?, осталось =
                       ?, телефон = ?,
                       заболевание = ?
                       WHERE id = ?''',
                    (self.surname, self.name,
                     self.pat, self.age, self.gender,
                     self.summa, self.ost,
                     self.num, self.disease, self.id))
        self.con.commit()
        result = cur.execute('SELECT * FROM patients').fetchall()
        ex.showing(result)
        self.close()

    def closing(self):
        self.close()


class Addition(QWidget, Ui_Form2):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.show()
        self.pushButton.clicked.connect(self.run)
        self.pushButton_2.clicked.connect(self.closing)

    def run(self):
        self.surname = self.lineEdit.text()
        self.name = self.lineEdit_2.text()
        self.pat = self.lineEdit_3.text()
        self.age = self.lineEdit_4.text()
        self.gender = self.lineEdit_5.text()
        self.summa = self.lineEdit_6.text()
        self.ost = self.lineEdit_7.text()
        self.num = self.lineEdit_8.text()
        self.disease = self.lineEdit_9.text()

        self.con = sqlite3.connect('pro_bd.db')
        cur = self.con.cursor()
        cur.execute('''INSERT INTO patients(фамилия,
                    имя, отчество, возраст, пол,
                    необходимо, осталось, телефон,
                    заболевание) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                    (self.surname,
                    self.name, self.pat, self.age,
                    self.gender, self.summa, self.ost,
                    self.num, self.disease))
        self.con.commit()
        result = cur.execute('SELECT * FROM patients').fetchall()
        ex.showing(result)
        self.close()

    def closing(self):
        self.close()


class Desc(QWidget):
    def __init__(self, text):
        super().__init__()
        self.text = text
        self.initUI()
    def initUI(self):
        self.setGeometry(600, 400, 400, 300)
        self.setWindowTitle('Описание проекта')

        self.button_1 = QPushButton(self)
        self.button_1.move(160, 270)
        self.button_1.setText("Закрыть")
        self.button_1.clicked.connect(self.run)

        self.description = QTextBrowser(self)
        self.description.setText(self.text)
        self.description.move(10, 10)
        self.description.resize(380, 260)

    def run(self):
        self.close()


app = QApplication(sys.argv)
ex = MyWidget()
ex.show()
sys.exit(app.exec_())
